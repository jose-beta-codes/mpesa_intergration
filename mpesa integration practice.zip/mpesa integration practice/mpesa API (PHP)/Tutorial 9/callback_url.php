<?php
  $stkCallbackResponse = file_get_contents('php://input');
  $logFile = "stkPushCallbackResponse.json";
  $log = fopen($logFile, "a");
  fwrite($log, $stkCallbackResponse);
  fclose($log);


  //decoding the json response
  $callbackdata= json_decode( $stkCallbackResponse);

  $resultcode=$callbackdata->body->stkCallback->ResultCode;
  $resultDesc=$callbackdata->body->stkCallback->ResultDesc;
  $merchantRequestID=$callbackdata->body->stkCallback->MerchantRequestID;
  $checkoutRequestID=$callbackdata->body->stkCallback->CheckoutRequestID;
  $name=$callbackdata->stkCallback->Body->CallbackMetadata->Item[0]->Name;
  $amount=$callbackdata->body->stkCallback->CallbackMetadata->Item[0]->Value;
  $Transactioncode=$callbackdata->Body->stkCallback->CallbackMetadata->Item[1]->Value;
  $phoneno=$callbackdata->body->stkCallback->CallbackMetadata->Item[4]->Value;


  $amount=strval($amount);
  require "mpesa-test-db-config.php";
  if($resultcode==0){
    $sql="INSERT INTO users (resultcode, mpesa_name, amount, transaction_code, mpesa_phoneno) VALUES ('$resultcode', '$name', '$amount', '$Transactioncode', '$phoneno');";
    if(mysqli_query($conn,$sql)){
      echo "<script> alert('Account activation successifull!')</script>";
      header("location: myExample-mpesa.php");
    }

  }