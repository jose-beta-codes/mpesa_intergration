<?php
session_start();

include "mpesa-test-db-config.php";
  $stkCallbackResponse = file_get_contents('php://input');
  $logFile = "stkPushCallbackResponse.json";
  $log = fopen($logFile, "a");
  fwrite($log, $stkCallbackResponse);
  


  //decoding the json response
  $callbackdata= json_decode( $stkCallbackResponse);

  //my jason
        $resultcode=empty($callbackdata->Body->stkCallback->ResultCode); //if successiful will return 1 
        
  
  if($resultcode==1){
        $resultdesc=$callbackdata->Body->stkCallback->ResultDesc;
        $amount=$callbackdata->Body->stkCallback->CallbackMetadata->Item[0]->Value;
        $Transactioncode=$callbackdata->Body->stkCallback->CallbackMetadata->Item[1]->Value;
        $TransactionDate=$callbackdata->Body->stkCallback->CallbackMetadata->Item[2]->Value;
        $phoneno=$callbackdata->Body->stkCallback->CallbackMetadata->Item[3]->Value;
        $formated_phoneno= str_replace("254", "0", $phoneno);


          $sql="INSERT INTO users (resultcode, amount, transaction_code, transaction_date, mpesa_phoneno) VALUES ('$resultcode', '$amount', '$Transactioncode', '$TransactionDate', '$formated_phoneno');";
          if(mysqli_query($conn,$sql)){
            $activation_messo="Success! Your account is now active, Lets start earning!";
            
          }else{
            echo "Error recording the transaction";
          }

  } 
  else{
    echo "Transaction Incomplete!";
  }fclose($log);