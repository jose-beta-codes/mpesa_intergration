<?php 
$num1="gh";
$num2=1;

$no1=!empty($num1);
$no2=empty($num2);
//if true it returns 1 when false it returns nothing(0)
//when item is empty =1, when item is not empty= 0, 
echo "the num1 is: ".$no1 ."num2 is: ".$no2;

$phoneno="254703615254";
$formated_phoneno= str_replace("254", "0", $phoneno);
echo $formated_phoneno;



// $callbackdata=json_decode($message);

        // $resultcode= !empty($callbackdata->ResponseCode); //will return a 1 when successifull
        // $responseDesc= !empty($callbackdata->ResponseDescription);
        // $resultDesc=$callbackdata->Body->stkCallback->ResultDesc;
        // $merchantRequestID=$callbackdata->Body->stkCallback->MerchantRequestID;
        // $checkoutRequestID=$callbackdata->Body->stkCallback->CheckoutRequestID;
        // $name=$callbackdata->stkCallback->Body->CallbackMetadata->Item[0]->Name;
        // $amount=$callbackdata->Body->stkCallback->CallbackMetadata->Item[0]->Value;
        // $Transactioncode=$callbackdata->Body->stkCallback->CallbackMetadata->Item[1]->Value;
        // $phoneno=$callbackdata->Body->stkCallback->CallbackMetadata->Item[4]->Value;

        //my json decode
        



        // echo  $resultcode;
        // echo  $resultdesc;
        // echo  $amount;
        // echo  $Transactioncode;
        // echo  $TransactionDate;
        // echo  $phoneno;






?>