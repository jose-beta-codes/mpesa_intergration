<?php
$servername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="mpesa_test";

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
if($conn==false){
    die("Error: can not connect.".mysqli_connect_error());
}