<?php
$servername="localhost";
$dbusername="root";
$dbpassword="";

$conn=mysqli_connect($servername, $dbusername, $dbpassword);
$sql="CREATE DATABASE mpesa_test;";
if(mysqli_query($conn,$sql)){
    echo("Successifully created the database mpesa_test!");
}

else{
    die ("Unknown error");
}
