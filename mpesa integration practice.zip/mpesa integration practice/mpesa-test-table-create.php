<?php
$servername="localhost";
$dbusername="root";
$dbpassword="";
$dbname="mpesa_test";

$conn=mysqli_connect($servername, $dbusername, $dbpassword, $dbname);
$sql="CREATE TABLE users(
    id INT(25) AUTO_INCREMENT PRIMARY KEY NOT NULL,
    resultcode INT(1) NOT NULL,
    amount INT(15) NOT NULL,
    transaction_code VARCHAR(25) NOT NULL,
    transaction_date VARCHAR(25) NOT NULL,
    mpesa_phoneno VARCHAR(15) NOT NULL
    );";

if(mysqli_query($conn,$sql)){
    echo "Table users successifully created!";
}
else{
    echo "Error creating table!";
}