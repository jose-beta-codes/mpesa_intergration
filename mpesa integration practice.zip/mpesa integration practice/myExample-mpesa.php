<?php
session_start();
$phone_err="";
if(isset($_POST['submit'])){
    
    if(empty($_POST['phone'])){
        $phone_err="Phone number cannot be empty!";
    }else{
    
    date_default_timezone_set('Africa/Nairobi');

  # access token
  $consumerKey = 'aMG7AWABrsFmPkp5iYasJVGfQ0TqmGZF'; //Fill with your app Consumer Key
  $consumerSecret = '05v0fo62zwGALpA1'; // Fill with your app Secret

  # define the variales
  # provide the following details, this part is found on your test credentials on the developer account
  $BusinessShortCode = '651207';//174379/// Small world bar till: 9763827 store no: 7836766 
  $Passkey = 'bfb279f9aa9bdbcf158e97dd71a467cd2e0c893059b10f78e6b72ada1ed2c919';  
  
  /*
    This are your info, for
    $PartyA should be the ACTUAL clients phone number or your phone number, format 2547********
    $AccountRefference, it maybe invoice number, account number etc on production systems, but for test just put anything
    TransactionDesc can be anything, probably a better description of or the transaction
    $Amount this is the total invoiced amount, Any amount here will be 
    actually deducted from a clients side/your test phone number once the PIN has been entered to authorize the transaction. 
    for developer/test accounts, this money will be reversed automatically by midnight.
  */
  
  $PartyA = $_POST['phone']; // This is your phone number, 
  $AccountReference = 'soko';
  $TransactionDesc = 'buy goods';
  $Amount = '1';
 
  # Get the timestamp, format YYYYmmddhms -> 20181004151020
  $Timestamp = date('YmdHis');    
  
  # Get the base64 encoded string -> $password. The passkey is the M-PESA Public Key
  $Password = base64_encode($BusinessShortCode.$Passkey.$Timestamp);

  # header for access token
  $headers = ['Content-Type:application/json; charset=utf8'];

    # M-PESA endpoint urls
  $access_token_url = 'https://sandbox.safaricom.co.ke/oauth/v1/generate?grant_type=client_credentials';
  $initiate_url = 'https://sandbox.safaricom.co.ke/mpesa/stkpush/v1/processrequest';

  # callback url
  $CallBackURL = 'https://e89d-197-156-137-175.in.ngrok.io/mpesa%20integration%20practice/test-mpesa-callbackurl.php';  

  $curl = curl_init($access_token_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $headers);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
  curl_setopt($curl, CURLOPT_HEADER, FALSE);
  curl_setopt($curl, CURLOPT_USERPWD, $consumerKey.':'.$consumerSecret);
  $result = curl_exec($curl);
  $status = curl_getinfo($curl, CURLINFO_HTTP_CODE);
  $result = json_decode($result);
  $access_token = $result->access_token;  
  curl_close($curl);

  # header for stk push
  $stkheader = ['Content-Type:application/json','Authorization:Bearer '.$access_token];

  # initiating the transaction
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $initiate_url);
  curl_setopt($curl, CURLOPT_HTTPHEADER, $stkheader); //setting custom header

  $curl_post_data = array(
    //Fill in the request parameters with valid values
    'BusinessShortCode' => $BusinessShortCode,
    'Password' => $Password,
    'Timestamp' => $Timestamp,
    'TransactionType' => 'CustomerPayBillOnline',//customerBuyGoodsOnline, CustomerPayBillOnline
    'Amount' => $Amount,
    'PartyA' => $PartyA,
    'PartyB' => $BusinessShortCode,
    'PhoneNumber' => $PartyA,
    'CallBackURL' => $CallBackURL,
    'AccountReference' => $AccountReference,
    'TransactionDesc' => $TransactionDesc
  );

  $data_string = json_encode($curl_post_data);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
  curl_setopt($curl, CURLOPT_POST, true);
  curl_setopt($curl, CURLOPT_POSTFIELDS, $data_string);
  $curl_response = curl_exec($curl);
  // print_r($curl_response);

  echo $curl_response;

  $callbackdata=json_decode($curl_response);
  ///++++++ is 1 when that item is present and empty string when it is not available
  //remember when the variable has a value of 0, then the empty function will take it as null/empty and will return a NULL 

  $resultcode= !empty($callbackdata->ResponseCode); //will return a 1 when successifull
  $responseDesc= !empty($callbackdata->ResponseDescription);
  //$resultcode=$callbackdata->ResponseDescription;
  //$resultcode=$callbackdata->ResponseDescription;
  //$errorcode=$callbackdata->errorCode;
  $errorcode = !empty($callbackdata->errorCode);
  if($resultcode==null && $responseDesc==1 ){
    echo "<h2><center>"."Mpesa pop-up successifully sent to your Phone" ."</center></h2>";
  }elseif($errorcode==1){
    echo "<h2><center>"."Error: either phone number is not mpesa-registered (invalid) or transaction is currently queued!" ."</center></h2>";
  }else{
    echo "<h2><center>"."Error: Unknown!" ."</center></h2>";
  }


}

}



?>




    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <style>
            body {
                background-color: dodgerblue;
            }
            
            .wrapper {
                text-align: center;
            }
        </style>
    </head>

    <body>
        <div class="wrapper">
            <p>
                <h2>Account activation through Mpesa</h2>
            </p>
            <form method="Post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                Activation fee is 1 Ksh
               <br>
                    <h3>Enter phone number to activate your account</h3>
                <br><span style="font-weight:bold; color:red;"><?php echo $phone_err;?></span><br>
                <label><i class="fa-solid fa-square-phone"></i></label><input type="tel" name="phone" placeholder="254xx xxxxxxx" /><br><br>
                <input type="submit" name="submit" value="Activate Account" style="background-color: rgb(214, 0, 0); border-radius: 30px;border:none; padding: 8px; color: white;" />
            </form>
            <!-- <b><?php echo htmlspecialchars($_SESSION["activation_message"]); ?></b> -->
        </div>

    </body>

    </html>